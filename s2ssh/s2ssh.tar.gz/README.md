# s2ssh
A simple OpenSSH client wrapper that connects with Scratch via cloud variables.
## Security concerns
**Important!**  
TBA  
**Please do not run until this section is completed**
## Installation
Latest build **Warning! Pre-releases may have security holes!**  
```sh
npm install https://github.com/Scratch-Cloud-Services/scratch-cloud-services/raw/s2ssh/s2ssh/s2ssh.tar.gz
```
Stable build  
TBA
## Usage
**Important!** Make sure to read the [Security Concerns](#security-concerns) first.  
```sh
s2ssh project-id [username@]host
```
## Package
```sh
make
```
