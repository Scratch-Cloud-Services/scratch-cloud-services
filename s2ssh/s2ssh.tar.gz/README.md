# s2ssh
A simple OpenSSH client wrapper that connects with Scratch via cloud variables.
## Security concerns
**Important!**  
TBA  
**Please do not run until this section is completed**
## Installation
```bash
git clone https://github.com/Scratch-Cloud-Services/scratch-cloud-services.git
cd scratch-cloud-services/s2ssh
npm install
```
